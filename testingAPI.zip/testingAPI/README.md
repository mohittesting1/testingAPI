to run this program, use maven from Intellij
double click on test from maven lifecycle,
package models;

public class Root {
    Parent[] parent;
}

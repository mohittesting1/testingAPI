package models;

public class Parent {
    public String id;
    public String name;
    public Data data;

}

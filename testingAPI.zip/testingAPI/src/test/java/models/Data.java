package models;

public class Data {
    public String color;
    public String capacity;
    public int capacity_GB;
    public double price;
    public double Price;
    public String generation;
    public int year;
    public String cPU_model;
    public String hard_disk_size;
    public String strap_Colour;
    public String case_Size;
    public String description;
    public double screen_size;
}

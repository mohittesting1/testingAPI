package com;

import com.google.gson.Gson;
import io.restassured.response.Response;
import models.Parent;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class testApi {

    @Test
    public void method() throws IOException {
        Gson gson = new Gson() ;

        Response res = given()
                .when()
                .get(PropertyReader.readPropertiesFile().getProperty("baseURL")+"/objects");
        Parent[] all = gson.fromJson(res.getBody().prettyPrint(), Parent[].class);
        System.out.println("Below are the list of phone names which starts with Apple and ID is not null");
        for(int i=0;i<all.length;i++){
            if(all[i].name.startsWith("Apple") && all[i].id != null){
                System.out.println(all[i].name);
            }
        }

        System.out.println("Finding the lowest price phone now");
        Map<String, Double> map = new HashMap<>();
        try{
            for(int i=0;i<all.length;i++){
                if(all[i].data != null) {
                    if (Double.parseDouble(String.valueOf(all[i].data.price)) > 0 && all[i].data.Price == 0.0) {
                        map.put(all[i].id, all[i].data.price);
                    }
                    else if (Double.parseDouble(String.valueOf(all[i].data.Price)) > 0 && all[i].data.price == 0.0){
                        map.put(all[i].id, all[i].data.Price);
                    }
                }
            }
        }
        catch (NullPointerException e){
            return;
        }

//        getting the lowest price key
        Map.Entry<String, Double> min = null;
        for (Map.Entry<String, Double> entry : map.entrySet()) {
            if (min == null || min.getValue() > entry.getValue()) {
                min = entry;
            }
        }

//      getting the phone by lowest price key
        for(int i=0;i<all.length;i++){
            if(all[i].id.equals(min.getKey())){
                System.out.println("Lowest price phone will be: "+all[i].name);
            }
        }

    }
}